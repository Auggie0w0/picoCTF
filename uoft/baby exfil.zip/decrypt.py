import os
import re

key = "G0G0Squ1d3Ncrypt10n"

def xor_file(data, key):
    """XOR decrypt - same function works both ways"""
    result = bytearray()
    for i in range(len(data)):
        result.append(data[i] ^ ord(key[i % len(key)]))
    return bytes(result)

def extract_hex_from_upload_file(upload_filepath):
    """Extract hex data from multipart form upload file"""
    with open(upload_filepath, 'r', encoding='latin-1') as f:
        content = f.read()
    
    # Split by double newline to separate headers from data
    # Format: boundary\nContent-Disposition...\n\nhex_data\nboundary
    parts = content.split('\n\n', 1)
    
    if len(parts) < 2:
        # Try single newline split
        parts = content.split('\n', 1)
        # Find the blank line after Content-Disposition
        idx = parts[0].find('\n\n')
        if idx != -1:
            hex_data = content[idx + 2:]
        else:
            # Fallback: find Content-Disposition and get everything after next blank line
            lines = content.split('\n')
            in_data = False
            hex_data = ""
            for line in lines:
                if 'Content-Disposition' in line:
                    in_data = False
                elif in_data or (line.strip() == '' and not in_data):
                    if line.strip() == '':
                        in_data = True
                        continue
                if in_data:
                    if line.strip().startswith('--'):
                        break
                    hex_data += line.strip()
    else:
        hex_data = parts[1]
    
    # Remove trailing boundary markers and whitespace
    hex_data = re.sub(r'--.*$', '', hex_data, flags=re.MULTILINE)
    hex_data = re.sub(r'\s+', '', hex_data)  # Remove all whitespace
    
    return hex_data

def decrypt_upload_file(upload_filepath, output_filepath):
    """Decrypt a file from the upload directory"""
    try:
        # Extract hex data from multipart form
        hex_data = extract_hex_from_upload_file(upload_filepath)
        
        # Convert hex string to bytes
        encrypted_bytes = bytes.fromhex(hex_data)
        
        # Decrypt using XOR
        decrypted = xor_file(encrypted_bytes, key)
        
        # Write decrypted data
        with open(output_filepath, 'wb') as f:
            f.write(decrypted)
        
        print(f"✓ Decrypted: {os.path.basename(upload_filepath)} -> {os.path.basename(output_filepath)}")
        return True
    except Exception as e:
        print(f"✗ Error decrypting {upload_filepath}: {e}")
        return False

# Main decryption process
base_path = r"/Users/augustlam/Downloads/ctf/uoft"

print("Decrypting encrypted image files...\n")

# Find all directories that look like encrypted image files
encrypted_dirs = []
for item in os.listdir(base_path):
    item_path = os.path.join(base_path, item)
    if os.path.isdir(item_path) and (item.endswith('.jpeg') or item.endswith('.png')):
        # Look for upload files inside
        for file in os.listdir(item_path):
            if file.startswith('upload'):
                upload_path = os.path.join(item_path, file)
                # Determine original filename from directory name
                original_name = item  # e.g., "3G2BHzj.jpeg"
                output_path = os.path.join(base_path, f"decrypted_{original_name}")
                decrypt_upload_file(upload_path, output_path)
                break

print("\nDecryption complete! Check for 'decrypted_*.jpeg' and 'decrypted_*.png' files.")
