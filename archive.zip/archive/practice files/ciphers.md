# Common cyphers

## CAESAR CIPHER
picoCTF{ynkooejcpdanqxeykjrbdofgkq}

##  BASE 64 & Caesar
YidkM0JxZGtwQlRYdHFhR3g2YUhsZmF6TnFlVGwzWVROclgyMHdNakV5TnpVNGZRPT0nCg==

## new_CAESAR
mlnklfnknljflfjljnjijjmmjkmljnjhmhjgjnjjjmmkjjmijhmkjhjpmkmkmljkjijnjpmhmjjgjj
- used keys/new_caesar.py to get 2 results

---
# RSA:
[Use this to factor](https://factordb.com/index.php?) to get p and q: 
*since this system disallowed me to install, had to use it in a VMware*

|c: 861270243527190895777142537838333832920579264010533029282104230006461420086153423
|n: 1311097532562595991877980619849724606784164430105441327897358800116889057763413423
|e: 65537